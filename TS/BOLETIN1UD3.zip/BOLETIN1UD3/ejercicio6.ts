setTimeout(function saluda() {
    alert("Hola");
}, 5000);