console.log("Nombre del navegador: " + window.navigator.appName);
console.log("Versión del navegador: " + window.navigator.appVersion);
//console.log("Tipo de conexión: " + window.navigator.conection);
console.log("Plataforma del navegador: " + window.navigator.platform);
