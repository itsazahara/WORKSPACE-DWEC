function validarDatos() {
    var expRegMail = new RegExp("[0-9][a-z][A-Z]");
    var mail = document.getElementById("mail");
    alert(mail.value);
}
