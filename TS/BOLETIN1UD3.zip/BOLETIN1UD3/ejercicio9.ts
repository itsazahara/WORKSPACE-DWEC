window.onbeforeunload = function () {
    return "Está seguro que desea salir?";
}