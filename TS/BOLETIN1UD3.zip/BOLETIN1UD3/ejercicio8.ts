window.onload = function saluda(){
    var parrafo = (document.getElementById("parrafo") as HTMLParagraphElement).nodeValue;
    alert("Hola");
}