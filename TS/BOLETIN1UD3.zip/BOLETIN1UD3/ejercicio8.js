window.onload = function saluda() {
    var parrafo = document.getElementById("parrafo").nodeValue;
    alert("Hola");
};
