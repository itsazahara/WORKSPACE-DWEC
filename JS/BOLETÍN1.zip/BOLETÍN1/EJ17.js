let numero = prompt("Introduzca un número, por favor:");

numero = Math.abs(numero);

let numeroCifras = numero.toString().length;

console.log("El número tiene " + numeroCifras + " cifras.");
