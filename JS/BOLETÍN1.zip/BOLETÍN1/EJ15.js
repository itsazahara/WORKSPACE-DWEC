var edad = prompt("Introduce tu edad: ");
var salir = confirm("¿Quieres salir del programa?");

if(salir){
    alert("El usuario quiere salir.");
}else{
    alert("El usuario no quiere salir.");
}

console.log("&cFIN DEL PROGRAMA", "color:blue", "font-weight:bold", "text-decoration:underline");