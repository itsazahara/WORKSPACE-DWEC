let parte1 = 'El acceso a la ruta C:\\\\usuario\\tarda 1’23”, ';
let parte2 = 'considerado “lento” en la actualidad.';
console.log(parte1 + 'algo ' + parte2);