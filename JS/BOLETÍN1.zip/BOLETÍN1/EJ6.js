var numero = 14;
var resultado = numero / 0 + 23;

console.log("El resultado es: " + resultado);