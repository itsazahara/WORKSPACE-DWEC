var numero = "hola" * 1;

console.log("El resultado es: " + numero);