var numDecimal = 12;
var numBinario = 0b10101;
var numHex = 0xABC;
var numOctal = 0x1239;

console.log("Número en formato decimal: " + numDecimal);
console.log("Número en formato binario: " + numBinario);
console.log("Número en formato hexadecimal: " + numHex);
console.log("Número en formato octal: " + numOctal);