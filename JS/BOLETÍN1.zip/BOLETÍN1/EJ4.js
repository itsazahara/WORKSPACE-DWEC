let valor = 2 * Math.pow(10, -9);
console.log(valor);