const datos = [
    { nombre: "Azahara", edad: 20, ciudad: "España" },
    { nombre: "Aitana", edad: 15, ciudad: "Inglaterra" },
    { nombre: "Carmen", edad: 53, ciudad: "Alemania" },
    { nombre: "Francisco Javier", edad: 50, ciudad: "Portugal" }
];

console.table(datos);

/*He estado buscando en internet varios ejemplos de cómo crear e inicializar un array,
aunque cuando le preguntas a ChatGPT por esta actividad te sale este ejemplo, en otras páginas 
lo suelen usar como ejemplo*/

/*Te dejo un enlace como demostración https://midu.dev/inicializar-array-con-valores/*/