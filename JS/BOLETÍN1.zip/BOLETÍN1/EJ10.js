{
    let var1 = "valor 1";
    var var2 = "Valor 2"

    console.log("La variable 1 es: " + var1);
    console.log("La variable 2 es: " + var2);
}

